from .WinWebV2 import WinWebV2 as WinWebV2
import sys
sys.modules[__name__] = WinWebV2
